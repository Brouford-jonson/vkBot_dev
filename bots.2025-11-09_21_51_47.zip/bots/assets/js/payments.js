// Обработка быстрого пополнения
document.addEventListener('DOMContentLoaded', function() {
    // Подсветка выбранной суммы
    const amountInput = document.getElementById('amount');
    const quickButtons = document.querySelectorAll('form[class*="h-100"]');
    
    quickButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            const form = this;
            const amount = form.querySelector('input[name="amount"]').value;
            amountInput.value = amount;
            
            // Подсветка активной кнопки
            quickButtons.forEach(btn => btn.classList.remove('active'));
            form.classList.add('active');
        });
    });
    
    // Валидация суммы
    amountInput.addEventListener('change', function() {
        const value = parseFloat(this.value);
        if (value < 10) {
            this.value = 10;
        } else if (value > 10000) {
            this.value = 10000;
        }
    });
});