// Обновление статистики каждые 30 секунд
function updateStats() {
    fetch('api/get_stats.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Обновляем данные на странице
                document.querySelectorAll('[data-stat]').forEach(element => {
                    const statName = element.getAttribute('data-stat');
                    if (data[statName] !== undefined) {
                        element.textContent = data[statName];
                    }
                });
            }
        })
        .catch(error => console.error('Error:', error));
}

// Автоматическое обновление каждые 30 секунд
setInterval(updateStats, 30000);

// Инициализация tooltips
document.addEventListener('DOMContentLoaded', function() {
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Подтверждение удаления
function confirmDelete(botName) {
    return confirm(`Вы уверены, что хотите удалить бота "${botName}"? Это действие нельзя отменить.`);
}