<?php
class Bot {
    private $conn;
    private $table_name = "bots";

    public $id;
    public $user_id;
    public $bot_name;
    public $bot_token;
    public $group_id;
    public $conversation_id;
    public $is_active;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                SET user_id=:user_id, bot_name=:bot_name, bot_token=:bot_token, 
                    group_id=:group_id, conversation_id=:conversation_id";
        
        $stmt = $this->conn->prepare($query);
        
        $this->bot_name = htmlspecialchars(strip_tags($this->bot_name));
        $this->bot_token = htmlspecialchars(strip_tags($this->bot_token));
        
        $stmt->bindParam(":user_id", $this->user_id);
        $stmt->bindParam(":bot_name", $this->bot_name);
        $stmt->bindParam(":bot_token", $this->bot_token);
        $stmt->bindParam(":group_id", $this->group_id);
        $stmt->bindParam(":conversation_id", $this->conversation_id);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function getBotsByUserId($user_id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE user_id = :user_id ORDER BY created_at DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":user_id", $user_id);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getCommandsCount($bot_id) {
        $query = "SELECT COUNT(*) as count FROM commands WHERE bot_id = :bot_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":bot_id", $bot_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                SET bot_name=:bot_name, bot_token=:bot_token, 
                    group_id=:group_id, conversation_id=:conversation_id,
                    is_active=:is_active
                WHERE id=:id AND user_id=:user_id";
        
        $stmt = $this->conn->prepare($query);
        
        $this->bot_name = htmlspecialchars(strip_tags($this->bot_name));
        $this->bot_token = htmlspecialchars(strip_tags($this->bot_token));
        
        $stmt->bindParam(":bot_name", $this->bot_name);
        $stmt->bindParam(":bot_token", $this->bot_token);
        $stmt->bindParam(":group_id", $this->group_id);
        $stmt->bindParam(":conversation_id", $this->conversation_id);
        $stmt->bindParam(":is_active", $this->is_active);
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":user_id", $this->user_id);
        
        return $stmt->execute();
    }

    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id AND user_id = :user_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->bindParam(":user_id", $this->user_id);
        return $stmt->execute();
    }

    public function getBotById($id) {
        $query = "SELECT * FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $id);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
    // new code
    public function getRolesCount($bot_id) {
        $query = "SELECT COUNT(*) as count FROM roles WHERE bot_id = :bot_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":bot_id", $bot_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'];
    }

    public function getBotWithUser($bot_id) {
        $query = "SELECT b.*, u.username, u.tariff 
                 FROM " . $this->table_name . " b 
                 JOIN users u ON b.user_id = u.id 
                 WHERE b.id = :bot_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":bot_id", $bot_id);
        $stmt->execute();
        
        if ($stmt->rowCount() == 1) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    public function canAddMoreRoles($bot_id, $user_tariff) {
        $current_roles = $this->getRolesCount($bot_id);
        $max_roles = $user_tariff == 'premium' ? 10 : 4;
        return $current_roles < $max_roles;
    }

    public function validateToken($token) {
        // Убираем пробелы в начале и конце
        $token = trim($token);
        
        // Проверяем длину токена (обычно 85 символов для user token, но может быть разной)
        if (strlen($token) < 50 || strlen($token) > 200) {
            return false;
        }
        
        // Проверяем базовый формат токена ВК
        // Токен может содержать буквы, цифры и некоторые специальные символы
        if (!preg_match('/^[a-zA-Z0-9_\-\.]+$/', $token)) {
            return false;
        }
        
        return true;
    }

    public function validateToken($token) {
        $token = trim($token);
        
        // Проверяем длину токена (новые токены ВК могут быть до 300 символов)
        if (strlen($token) < 80 || strlen($token) > 300) {
            return false;
        }
        
        // Проверяем формат токена ВК
        // Новые токены начинаются с vk1.a. и содержат буквы, цифры, дефисы, подчеркивания
        if (preg_match('/^vk1\.[a-z]\.[a-zA-Z0-9_\-]+$/', $token)) {
            return true;
        }
        
        // Старые токены (85 символов, только буквы и цифры)
        if (preg_match('/^[a-zA-Z0-9]{85}$/', $token)) {
            return true;
        }
        
        // Дополнительная проверка для других форматов
        if (preg_match('/^[a-zA-Z0-9_\-]{80,}$/', $token)) {
            return true;
        }
        
        return false;
    }

    // Упрощенная проверка токена (только базовые проверки)
    public function validateTokenSimple($token) {
        $token = trim($token);
        
        // Минимальная проверка длины
        if (strlen($token) < 80) {
            return false;
        }
        
        // Проверяем на наличие опасных символов
        if (preg_match('/[<>"\']/', $token)) {
            return false;
        }
        
        return true;
    }

    // Тестирование токена через API ВК
    public function testToken($token) {
        // Пробуем разные методы API для проверки токена
        
        // Метод 1: groups.get (для токенов сообществ)
        $url1 = "https://api.vk.com/method/groups.get?access_token=" . $token . "&v=5.131";
        
        // Метод 2: users.get (для пользовательских токенов)
        $url2 = "https://api.vk.com/method/users.get?access_token=" . $token . "&v=5.131";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        if ($http_code === 200) {
            $data = json_decode($response, true);
            
            // Если нет ошибки, токен валиден
            if (!isset($data['error'])) {
                curl_close($ch);
                return true;
            }
        }
        
        // Пробуем второй метод
        curl_setopt($ch, CURLOPT_URL, $url2);
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($http_code === 200) {
            $data = json_decode($response, true);
            return !isset($data['error']);
        }
        
        return false;
    }
}
?>