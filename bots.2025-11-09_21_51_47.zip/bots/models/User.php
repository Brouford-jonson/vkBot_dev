<?php
class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $username;
    public $email;
    public $password;
    public $balance;
    public $tariff;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                SET username=:username, email=:email, password=:password";
        
        $stmt = $this->conn->prepare($query);
        
        $this->username = htmlspecialchars(strip_tags($this->username));
        $this->email = htmlspecialchars(strip_tags($this->email));
        $this->password = password_hash($this->password, PASSWORD_DEFAULT);
        
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->bindParam(":password", $this->password);
        
        if ($stmt->execute()) {
            return true;
        }
        return false;
    }

    public function getUserById() {
        $query = "SELECT id, username, email, balance, tariff FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        $stmt->execute();
        
        if ($stmt->rowCount() == 1) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    public function updateBalance($amount) {
        $query = "UPDATE " . $this->table_name . " 
                SET balance = balance + :amount 
                WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":amount", $amount);
        $stmt->bindParam(":id", $this->id);
        
        return $stmt->execute();
    }

    public function updateTariff($tariff) {
        $query = "UPDATE " . $this->table_name . " 
                SET tariff = :tariff 
                WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":tariff", $tariff);
        $stmt->bindParam(":id", $this->id);
        
        return $stmt->execute();
    }

    // Метод для проверки существования пользователя
    public function userExists() {
        $query = "SELECT id FROM " . $this->table_name . " 
                 WHERE username = :username OR email = :email";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":email", $this->email);
        $stmt->execute();
        return $stmt->rowCount() > 0;
    }
    // payments
     public function canCreateMoreBots() {
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "SELECT COUNT(*) as count FROM bots WHERE user_id = :user_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":user_id", $this->id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $max_bots = $this->tariff == 'premium' ? 20 : 5; // Лимиты по тарифам
        
        return $result['count'] < $max_bots;
    }

    public function canCreateMoreRoles($bot_id) {
        $database = new Database();
        $db = $database->getConnection();
        
        $query = "SELECT COUNT(*) as count FROM roles WHERE bot_id = :bot_id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(":bot_id", $bot_id);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $max_roles = $this->tariff == 'premium' ? 10 : 4; // Лимиты по тарифам
        
        return $result['count'] < $max_roles;
    }

    public function canCreateCustomCommands() {
        return $this->tariff == 'premium';
    }

    public function hasSufficientBalance($amount) {
        return $this->balance >= $amount;
    }

    public function deductBalance($amount) {
        if ($this->hasSufficientBalance($amount)) {
            $query = "UPDATE " . $this->table_name . " 
                    SET balance = balance - :amount 
                    WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":amount", $amount);
            $stmt->bindParam(":id", $this->id);
            
            return $stmt->execute();
        }
        return false;
    }
}
?>